from .train_net import main
main()