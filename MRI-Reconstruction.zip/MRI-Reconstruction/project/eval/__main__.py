from .eval_net import main
main()