from .test_net import main
main()